﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports iTextSharp.text.html
Imports iTextSharp.text.html.simpleparser
Partial Class storage_apply
    Inherits System.Web.UI.Page
    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
        '處理'GridView' 的控制項 'GridView' 必須置於有 runat=server 的表單標記之中
    End Sub
    Protected Sub btnExportExcel_Click(ByVal sender As Object, ByVal e As EventArgs)
        Response.Clear()
        Response.Buffer = True

        Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"

        Dim sw As New StringWriter()
        Dim hw As New HtmlTextWriter(sw)

        GridView1.AllowPaging = False
        GridView1.DataBind()

        'Change the Header Row back to white color
        GridView1.HeaderRow.Style.Add("background-color", "#FFFFFF")

        'Apply style to Individual Cells
        GridView1.HeaderRow.Cells(0).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(1).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(2).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(3).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(4).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(5).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(6).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(7).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(8).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(9).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(10).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(11).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(12).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(13).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(14).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(15).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(16).Style.Add("background-color", "#bf3e11")
        GridView1.HeaderRow.Cells(17).Style.Add("background-color", "#bf3e11")
        For i As Integer = 0 To GridView1.Rows.Count - 1
            Dim row As GridViewRow = GridView1.Rows(i)

            'Change Color back to white
            row.BackColor = System.Drawing.Color.White

            'Apply text style to each Row
            row.Attributes.Add("class", "textmode")

            'Apply style to Individual Cells of Alternating Row
            If i Mod 2 <> 0 Then
                row.Cells(0).Style.Add("background-color", "#FFD9D9")
                row.Cells(1).Style.Add("background-color", "#FFD9D9")
                row.Cells(2).Style.Add("background-color", "#FFD9D9")
                row.Cells(3).Style.Add("background-color", "#FFD9D9")
                row.Cells(4).Style.Add("background-color", "#FFD9D9")
                row.Cells(5).Style.Add("background-color", "#FFD9D9")
                row.Cells(6).Style.Add("background-color", "#FFD9D9")
                row.Cells(7).Style.Add("background-color", "#FFD9D9")
                row.Cells(8).Style.Add("background-color", "#FFD9D9")
                row.Cells(9).Style.Add("background-color", "#FFD9D9")
                row.Cells(10).Style.Add("background-color", "#FFD9D9")
                row.Cells(11).Style.Add("background-color", "#FFD9D9")
                row.Cells(12).Style.Add("background-color", "#FFD9D9")
                row.Cells(13).Style.Add("background-color", "#FFD9D9")
                row.Cells(14).Style.Add("background-color", "#FFD9D9")
                row.Cells(15).Style.Add("background-color", "#FFD9D9")
                row.Cells(16).Style.Add("background-color", "#FFD9D9")
                row.Cells(17).Style.Add("background-color", "#FFD9D9")
            End If
        Next
        GridView1.RenderControl(hw)

        'style to format numbers to string
        Dim style As String = "<style>.textmode{mso-number-format:\@;}</style>"
        Response.Write(style)
        Response.Output.Write(sw.ToString())
        Response.Flush()
        Response.End()
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        

        If Convert.ToString(Session("user")) = "" Then
            Response.Redirect("Default.aspx")
        End If
        txt_year.Text = Request("year")
        lbl_title.Text = Request("title")
    End Sub
End Class
