/**
 * ...
 * @author Ogilvy Mather Digital - 衝康吉
 * Wellcome to read this source code.
 * I might try to use code name follow next row
 * 
 * init/get/set/is/clear/evt/with/sync
 * release/add/remove/addEventListener/on
 * ...
 */
