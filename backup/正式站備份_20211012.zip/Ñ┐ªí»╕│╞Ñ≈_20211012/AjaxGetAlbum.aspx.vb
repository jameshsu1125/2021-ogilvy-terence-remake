﻿Imports System
Imports System.Web.Services
Imports System.Web.Script.Services
Imports System.Web.Configuration
Imports System.Data.SqlClient

Partial Class AjaxGetAlbum
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            ' 第一次執行程式，才會運作到此....
            '填入資料庫資料

            Dim con1 As SqlConnection = New SqlConnection
            con1.ConnectionString = WebConfigurationManager.ConnectionStrings("redConnectionString").ConnectionString()
            con1.Open()

            Dim SqlString1 As String
            If (Request("periodId") = "all") Then
                SqlString1 = "SELECT * FROM period  ORDER By id DESC "
            ElseIf (Request("periodId") Mod 1 = 0) Then
                SqlString1 = "SELECT * FROM period WHERE id=@periodId ORDER By id DESC "

            End If
            Dim cmd1 As SqlCommand = New SqlCommand(SqlString1, con1)
            cmd1.Parameters.AddWithValue("@periodId", Request("periodId"))
            Dim result As String = cmd1.ExecuteNonQuery()
            Dim dr As SqlDataReader = cmd1.ExecuteReader()


            Dim jsonStr As String
            jsonStr += "{"
            If dr.HasRows Then
                Do While dr.Read
                    'Response.Write(dr.Item("engtitle").ToString().Trim() + "<br/>")
                    jsonStr += "'" + dr.Item("engtitle").ToString().Trim() + "':["
                    Dim con2 As SqlConnection = New SqlConnection
                    con2.ConnectionString = WebConfigurationManager.ConnectionStrings("redConnectionString").ConnectionString()
                    con2.Open()
                    Dim SqlString2 As String = "SELECT photo.id, photo.periodId, photo.base64, photo.base64thumb, photo.createtime, period.id AS pid,year AS year, period.engtitle as engtitle FROM photo LEFT OUTER JOIN period ON photo.periodId = period.id WHERE photo.periodId=@periodId ORDER By photo.id DESC"

                    Dim cmd2 As SqlCommand = New SqlCommand(SqlString2, con2)
                    cmd2.Parameters.AddWithValue("@periodId", dr.Item("id").ToString().Trim())
                    Dim result2 As String = cmd2.ExecuteNonQuery()
                    Dim dr2 As SqlDataReader = cmd2.ExecuteReader()
                    Dim byt As Byte()
                    Dim bytthumb As Byte()
                    If dr2.HasRows Then
                        Do While dr2.Read
                            byt = Convert.FromBase64String(dr2.Item("base64").ToString().Trim())
                            Dim base64 = System.Text.Encoding.UTF8.GetString(byt)
                            bytthumb = Convert.FromBase64String(dr2.Item("base64thumb").ToString().Trim())
                            Dim base64thumb = System.Text.Encoding.UTF8.GetString(bytthumb)
                            jsonStr += "{'id':'" + dr2.Item("id").ToString().Trim() + "','year':'" + dr2.Item("year").ToString().Trim() + "','engTitle':'" + dr2.Item("engTitle").ToString().Trim() + "','base64thumb':'" + HttpUtility.UrlEncode(base64thumb) + "','base64':'" + HttpUtility.UrlEncode(base64) + "'},"
                            'jsonStr += "{'id':'" + dr2.Item("id").ToString().Trim() + "','base64':'" + HttpUtility.UrlEncode(base64) + ",'base64thumb':'" + HttpUtility.UrlEncode(base64thumb) + "'},"
                            'Response.Write("<img src='" + base64thumb + "' />")
                            'Response.Write("　" + "<a target='temp' href='trainee.aspx?id=" + dr2.Item("id").ToString().Trim() + "'>" + dr2.Item("chiname").ToString().Trim() + "</a><br/>")
                        Loop
                        'Response.Write("<br/>")
                    End If
                    jsonStr += "],"
                    con2.Close()
                    con2.Dispose()

                    ' photolist.Text += "<tr>"
                    ' photolist.Text += "<td>" + dr.Item("id").ToString().Trim() + "</td>"
                    'photolist.Text += "<td>" + dr.Item("periodId").ToString().Trim() + "</td>"
                    'Label1.Text += "<td>" + dr.Item("filename").ToString().Trim() + "</td>"
                    'Label1.Text += "<td><img src='" + base64 + "' /></td>"
                    ' photolist.Text += "<img src='" + base64thumb + "' />"
                    'photolist.Text += "<td>" + dr.Item("createtime").ToString() + "</td>"
                    'photolist.Text += "<td><a target='tempframe' href='deletePhoto.aspx?photoId=" + dr.Item("id").ToString().Trim() + "' onClick='return confirm(""確定要刪除嗎？"")'>刪除</a></td>"
                    'photolist.Text += "</tr>"


                Loop
            End If
            jsonStr += "}"
            jsonStr = jsonStr.Replace("},]", "}]")
            jsonStr = jsonStr.Replace(",],", "]")
            jsonStr = jsonStr.Replace("],}", "]}")
            Response.Write(jsonStr)
            con1.Close()
            con1.Dispose()

        End If
    End Sub
End Class
