﻿Imports System
Imports System.Web.Services
Imports System.Web.Script.Services
Imports System.Web.Configuration
Imports System.Data.SqlClient

Public Class AjaxSetValue
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim createtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Dim realname As String = Request("realname")
        Dim sex As String = Request("sex")
        Dim birthday As String = Request("birthday")
        Dim phone As String = Request("phone")
        Dim mobile As String = Request("mobile")
        Dim email As String = Request("email")
        Dim address As String = Request("address")
        Dim school As String = Request("school")
        Dim department As String = Request("department")
        Dim grade As String = Request("grade")
        Dim graduation_time As String = Request("graduation_time")
        Dim want As String = Request("want")
        Dim experience As String = Request("experience")


        'Dim EmailRegex As Regex = New Regex("^([\w-\.]+)@(([\w-]+\.)+)([a-zA-Z]{2,4})$")
        'Dim TelRegex As Regex = New Regex("^(0)(9)([0-9]{8})$")
        'Dim NameRegex As Regex = New Regex("[\W_]+")

        Dim msg As String
        msg = ""
        Dim nowTime = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Dim startTime As DateTime
        Dim endTime As DateTime
        Dim con2 As SqlConnection = New SqlConnection
        con2.ConnectionString = WebConfigurationManager.ConnectionStrings("redConnectionString").ConnectionString()
        con2.Open()
        Dim SqlString2 As String = "SELECT * FROM applyTime"

        Dim cmd2 As SqlCommand = New SqlCommand(SqlString2, con2)
        Dim result2 As String = cmd2.ExecuteNonQuery()
        Dim dr2 As SqlDataReader = cmd2.ExecuteReader()
        If dr2.HasRows Then
            Do While dr2.Read
                startTime = [DateTime].Parse(String.Format("{0:yyyy/MM/dd HH:mm:ss}", dr2.Item("startTime")).ToString().Trim())
                endTime = [DateTime].Parse(String.Format("{0:yyyy/MM/dd HH:mm:ss}", dr2.Item("endTime")).ToString().Trim())
            Loop
        End If

        con2.Close()
        con2.Dispose()









        If (nowTime >= startTime And nowTime <= endTime) Then
            'Response.Write("go")
        Else
            msg += "請於2015年2月14日00:00 開始上網登錄，填妥報名表並下載列印。"
        End If
        'If EmailRegex.IsMatch(email) <> True Then
        '    msg += " 請正確輸入Mail"
        'End If
        'If TelRegex.IsMatch(tel) <> True Then
        '    msg += " 請正確輸入電話"
        'End If
        'name = Regex.Replace(name, "[\W_]+", "")





        If (msg = "") Then
            'Dim connectionString1 As String = "server=211.78.81.131;uid=redworks;pwd=dbformittw;database=mittw"

            'Dim connectionString1 As String = "Data Source=.\SqlExpress; Initial Catalog=mit; Integrated Security=SSPI"
            Dim con1 As SqlConnection = New SqlConnection
            con1.ConnectionString = WebConfigurationManager.ConnectionStrings("redConnectionString").ConnectionString()
            con1.Open()

            Dim SqlString1 As String = "INSERT INTO apply(Name, Sex, Birthday,Phone,Mobile,Email,Address,School,Department,Grade,GraduationTime,Want,Experience,CreateTime) VALUES(@realname,@sex,@birthday,@phone,@mobile,@email,@address,@school,@department,@grade,@graduation_time,@want,@experience,@createtime);SELECT SCOPE_IDENTITY()"
            Dim cmd1 As SqlCommand = New SqlCommand(SqlString1, con1)

            cmd1.Parameters.AddWithValue("@realname", realname)
            cmd1.Parameters.AddWithValue("@sex", sex)
            cmd1.Parameters.AddWithValue("@birthday", birthday)
            cmd1.Parameters.AddWithValue("@phone", phone)
            cmd1.Parameters.AddWithValue("@mobile", mobile)
            cmd1.Parameters.AddWithValue("@email", email)
            cmd1.Parameters.AddWithValue("@address", address)
            cmd1.Parameters.AddWithValue("@school", school)
            cmd1.Parameters.AddWithValue("@department", department)
            cmd1.Parameters.AddWithValue("@grade", grade)
            cmd1.Parameters.AddWithValue("@graduation_time", graduation_time)
            cmd1.Parameters.AddWithValue("@want", want)
            cmd1.Parameters.AddWithValue("@experience", experience)
            cmd1.Parameters.AddWithValue("@createtime", createtime)
            Dim _Id As Integer = cmd1.ExecuteScalar
            'Dim result As String = cmd1.ExecuteNonQuery()

            con1.Close()
            con1.Dispose()
            Response.Write(_Id.ToString().PadLeft(4, "0"))
            Session("applyId") = _Id.ToString()
        Else
            Response.Write(msg)
        End If

        ' If (result = "1") Then
        ' Response.Write("會員資料已寫入")
        'End If



        'Dim dr As SqlDataReader = cmd1.ExecuteReader()




        'Response.Write(dr.Item("name").ToString())
        'If dr.HasRows Then
        '    Do While dr.Read
        '        Response.Write("1")

        '    Loop
        'Else
        '    Response.Write("0")
        'End If

        'dr.Close()

    End Sub

End Class