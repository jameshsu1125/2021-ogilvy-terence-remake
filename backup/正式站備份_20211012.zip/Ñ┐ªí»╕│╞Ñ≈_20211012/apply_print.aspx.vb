﻿Imports System
Imports System.Web.Services
Imports System.Web.Script.Services
Imports System.Web.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports iTextSharp.text.html
Imports iTextSharp.text.html.simpleparser

Partial Class apply_print
    Inherits System.Web.UI.Page
    Public realname As String
    Public sex As String
    Public birthday As String()
    Public phone As String
    Public mobile As String
    Public email As String
    Public address As String
    Public school As String
    Public department As String
    Public grade As String
    Public graduation_time As String
    Public want As String
    Public experience As String
    Public myId As String
    Public host As String

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        host = Request.Url.Host
        realname = Request("realname")
        sex = Request("sex")
        birthday = Request("birthday").ToString().Split("-")

        phone = Request("phone")
        mobile = Request("mobile")
        email = Request("email")
        address = Request("address")
        school = Request("school")
        department = Request("department")
        grade = Request("grade")
        graduation_time = Request("graduation_time")
        want = Request("want")
        experience = Request("experience")
        myId = Request("myId")
        ' Response.Write(birthday(0))



    End Sub

    
End Class
