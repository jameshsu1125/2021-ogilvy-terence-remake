﻿Imports System
Imports System.Web.Services
Imports System.Web.Script.Services
Imports System.Web.Configuration
Imports System.Data.SqlClient

Partial Class storage_album
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Convert.ToString(Session("user")) = "" Then
            Response.Redirect("Default.aspx")
        End If
        periodId.Text = Request("periodId")
        lbl_title.Text = Request("title")
        If Not Page.IsPostBack Then

            ' 第一次執行程式，才會運作到此....
            '填入資料庫資料

            Dim con1 As SqlConnection = New SqlConnection
            con1.ConnectionString = WebConfigurationManager.ConnectionStrings("redConnectionString").ConnectionString()
            con1.Open()

            Dim SqlString1 As String = "SELECT TOP (100) id, periodId, base64,base64thumb, createtime FROM photo WHERE periodId='" + Request("periodId") + "' Order By id DESC"

            Dim cmd1 As SqlCommand = New SqlCommand(SqlString1, con1)

            Dim result As String = cmd1.ExecuteNonQuery()
            Dim dr As SqlDataReader = cmd1.ExecuteReader()


            Dim byt As Byte()
            Dim bytthumb As Byte()
            If dr.HasRows Then
                Do While dr.Read
                    byt = Convert.FromBase64String(dr.Item("base64").ToString().Trim())
                    Dim base64 = System.Text.Encoding.UTF8.GetString(byt)
                    bytthumb = Convert.FromBase64String(dr.Item("base64thumb").ToString().Trim())
                    Dim base64thumb = System.Text.Encoding.UTF8.GetString(bytthumb)

                    photolist.Text += "<tr>"
                    photolist.Text += "<td>" + dr.Item("id").ToString().Trim() + "</td>"
                    photolist.Text += "<td>" + dr.Item("periodId").ToString().Trim() + "</td>"
                    'Label1.Text += "<td>" + dr.Item("filename").ToString().Trim() + "</td>"
                    'Label1.Text += "<td><img src='" + base64 + "' /></td>"
                    photolist.Text += "<td><img src='" + base64thumb + "' /></td>"
                    photolist.Text += "<td>" + dr.Item("createtime").ToString() + "</td>"
                    photolist.Text += "<td><a target='tempframe' href='deletePhoto.aspx?photoId=" + dr.Item("id").ToString().Trim() + "' onClick='return confirm(""確定要刪除嗎？"")'>刪除</a></td>"
                    photolist.Text += "</tr>"


                Loop
            End If

            con1.Close()
            con1.Dispose()
        End If
    End Sub

   
End Class
