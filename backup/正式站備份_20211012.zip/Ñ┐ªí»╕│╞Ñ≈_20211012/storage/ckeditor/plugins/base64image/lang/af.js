/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","af",{
	"alt":"Alternatiewe teks",
	"lockRatio":"Vaste proporsie",
	"vSpace":"VSpasie",
	"hSpace":"HSpasie",
	"border":"Rand"
});