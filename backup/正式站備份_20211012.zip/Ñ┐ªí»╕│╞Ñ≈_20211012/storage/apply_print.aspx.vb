﻿Imports System
Imports System.Web.Services
Imports System.Web.Script.Services
Imports System.Web.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports iTextSharp.text.html
Imports iTextSharp.text.html.simpleparser
Partial Class apply_print
    Inherits System.Web.UI.Page
    Public id As String
    Public nowYear As String
    Public realname As String
    Public sex As String
    Public birthday As String()
    Public phone As String
    Public mobile As String
    Public email As String
    Public address As String
    Public school As String
    Public department As String
    Public grade As String
    Public graduation_time As String
    Public want As String
    Public experience As String
    Public host As String
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        nowYear = DateTime.Today.Year()
        id = Request("id").PadLeft(4, "0")
        host = Request.Url.Host
        ' 第一次執行程式，才會運作到此....
        '填入資料庫資料





        Dim con1 As SqlConnection = New SqlConnection
        con1.ConnectionString = WebConfigurationManager.ConnectionStrings("redConnectionString").ConnectionString()
        con1.Open()

        Dim SqlString1 As String = "SELECT * FROM apply WHERE(id = '" + Request("id") + "')"

        Dim cmd1 As SqlCommand = New SqlCommand(SqlString1, con1)

        Dim result As String = cmd1.ExecuteNonQuery()
        Dim dr As SqlDataReader = cmd1.ExecuteReader()



        If dr.HasRows Then
            Do While dr.Read
                realname = dr.Item("Name").ToString().Trim()
                sex = dr.Item("Sex").ToString().Trim()
                birthday = Format(dr.Item("Birthday"), "yyyy-MM-dd").ToString().Split("-")
                phone = dr.Item("Phone").ToString().Trim()
                mobile = dr.Item("Mobile").ToString().Trim()
                email = dr.Item("Email").ToString().Trim()
                address = dr.Item("Address").ToString().Trim()
                school = dr.Item("School").ToString().Trim()
                department = dr.Item("Department").ToString().Trim()
                grade = dr.Item("Grade").ToString().Trim()
                graduation_time = Format(dr.Item("GraduationTime"), "yyyy-MM-dd").ToString().Trim()
                want = dr.Item("Want").ToString().Trim()
                experience = dr.Item("Experience").ToString().Trim()


            Loop
        End If

        con1.Close()
        con1.Dispose()




        ' Response.Write(birthday(0))


        If (Request("act") = "download") Then

            Response.Clear()
            Response.Buffer = True
            Response.AddHeader("content-disposition", "attachment;filename=" + id + realname + ".doc")
            Response.Charset = ""
            Response.ContentType = "application/vnd.ms-word "
            Dim sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)
            'pnlPerson.AllowPaging = False
            pnlPerson.DataBind()
            pnlPerson.RenderControl(hw)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End If



    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Dim FontPath As String = "c:\windows\fonts\KAIU.TTF"
        'Dim bf As BaseFont = BaseFont.CreateFont(FontPath, BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED)
        'Dim fn As Font = New Font(bf, 10)


        ' Dim tab As New PdfPTable(3)
        ' Dim headerwidth() As Single = {50, 25, 25}
        ' tab.SetWidths(headerwidth)
        ' tab.HeaderRows = 1
        ' tab.AddCell(New Paragraph("日期", fn))

        Response.ContentType = "application/pdf"
        Response.ContentEncoding = System.Text.Encoding.UTF8
        Response.AddHeader("content-disposition", "attachment;filename=Panel.pdf")
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Dim sw As New StringWriter()
        Dim hw As New HtmlTextWriter(sw)
        pnlPerson.RenderControl(hw)
        Dim sr As New StringReader(sw.ToString())
        Dim pdfDoc As New Document(PageSize.A4, 0.0F, 0.0F, 0.0F, 0.0F)
        Dim htmlparser As New HTMLWorker(pdfDoc)
        Dim fontPath As String = Environment.GetFolderPath(Environment.SpecialFolder.System) + "\..\Fonts\mingliub.ttc"
        FontFactory.Register(fontPath) '登記文字樣式路徑
        Dim fontchinese As Font = FontFactory.GetFont("新細明體", BaseFont.IDENTITY_H, 16.0F)
        'Dim BaseF As BaseFont = BaseFont.CreateFont("C:\Windows\system32\Fonts\MINGLIU.TTC", BaseFont.IDENTITY_H, BaseFont.EMBEDDED)
        'Dim font As New iTextSharp.text.Font(BaseF, 16)

        PdfWriter.GetInstance(pdfDoc, Response.OutputStream)
        pdfDoc.Open()
        htmlparser.Parse(sr)
        pdfDoc.Close()
        Response.Write(pdfDoc)
        Response.End()

        'word
        'Response.Clear()
        'Response.Buffer = True
        'Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.doc")
        'Response.Charset = ""
        'Response.ContentType = "application/vnd.ms-word "
        'Dim sw As New StringWriter()
        'Dim hw As New HtmlTextWriter(sw)
        ''pnlPerson.AllowPaging = False
        'pnlPerson.DataBind()
        'pnlPerson.RenderControl(hw)
        'Response.Output.Write(sw.ToString())
        'Response.Flush()
        'Response.[End]()


    End Sub

    
End Class
