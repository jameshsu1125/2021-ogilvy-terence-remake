﻿Imports System
Imports System.Web.Services
Imports System.Web.Script.Services
Imports System.Web.Configuration
Imports System.Data.SqlClient

Partial Class storage_AjaxAddPhoto
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim createtime = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Dim periodId As String = Request("periodId")
        Dim filename As String = Request("filename")
        'Dim createtime As String = Request("createtime")


        Dim byt As Byte() = System.Text.Encoding.UTF8.GetBytes(Request("base64"))
        Dim base64 = Convert.ToBase64String(byt)

        Dim bytthumb As Byte() = System.Text.Encoding.UTF8.GetBytes(Request("base64thumb"))
        Dim base64thumb = Convert.ToBase64String(bytthumb)

        'Dim byt2 As Byte() = Convert.FromBase64String(base64)
        'Dim base642 = System.Text.Encoding.UTF8.GetString(byt2)

        'Response.Write(base642)

        Dim msg As String
        msg = ""
        'If EmailRegex.IsMatch(email) <> True Then
        '    msg += " 請正確輸入Mail"
        'End If
        'If TelRegex.IsMatch(tel) <> True Then
        '    msg += " 請正確輸入電話"
        'End If
        'name = Regex.Replace(name, "[\W_]+", "")





        If (msg = "") Then
            Dim con1 As SqlConnection = New SqlConnection
            con1.ConnectionString = WebConfigurationManager.ConnectionStrings("redConnectionString").ConnectionString()
            con1.Open()

            Dim SqlString1 As String = "INSERT INTO photo(periodId,base64,base64thumb,createtime) VALUES(@periodId,@base64,@base64thumb,@createtime)"

            Dim cmd1 As SqlCommand = New SqlCommand(SqlString1, con1)

            cmd1.Parameters.AddWithValue("@periodId", periodId)
            'cmd1.Parameters.AddWithValue("@filename", filename)
            cmd1.Parameters.AddWithValue("@base64", base64)
            cmd1.Parameters.AddWithValue("@base64thumb", base64thumb)
            cmd1.Parameters.AddWithValue("@createtime", createtime)
            Dim result As String = cmd1.ExecuteNonQuery()
            con1.Close()
            con1.Dispose()
            Response.Write("")

        Else
            Response.Write(msg)
        End If

        ' If (result = "1") Then
        ' Response.Write("會員資料已寫入")
        'End If



        'Dim dr As SqlDataReader = cmd1.ExecuteReader()




        'Response.Write(dr.Item("name").ToString())
        'If dr.HasRows Then
        '    Do While dr.Read
        '        Response.Write("1")

        '    Loop
        'Else
        '    Response.Write("0")
        'End If

        'dr.Close()

      

    End Sub





End Class


